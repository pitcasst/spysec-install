<!DOCTYPE html>
<html>
	<head>
		<title>Conessis</title>
		<meta charset="utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
			
		<link rel="stylesheet" href="css/bsc.css">
		<link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
		<link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
		<link rel="stylesheet" href="dist/css/AdminLTE.min.css">

		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">

		<script src="bower_components/jquery/dist/jquery.min.js"></script>
		<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
		<script src="bower_components/fastclick/lib/fastclick.js"></script> 
		<script src="dist/js/adminlte.min.js"></script>
		
	</head>	
	<?php include 'inc/inc_db.php'; include 'php/variables.php'; if($dbstanew == 1 && $dbact == 0){?>
	<body class="hold-transition register-page">
		<div class="register-box">
			<section class="content">
				<div class="box box-warning">
					<div class="box-body box-profile">
						<img class="profile-user-img img-responsive img-circle" src="img/<?php echo $dbimg ?>" alt="User profile picture">
						<h3 class="profile-username text-center"><?php echo $dbnmb.' '.$dbape ?></h3>
						<p class="text-muted text-center"><?php echo $dbpue ?></p>
						<ul class="list-group list-group-unbordered">
							<li class="list-group-item text-center">
								<b >Usuario no activado.</b>
							</li>
						</ul>
						<a href="php/logout.php" class="btn btn-warning btn-block"><b>Salir</b></a>
					</div>
				</div>
    		</section>
		</div>
		<?php } else { echo '<meta http-equiv="refresh" content="0; url=/pruebas/sub-paginas/dashboard.php">'; } ?>
	</body>
	
</html>
