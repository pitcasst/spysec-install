<?php

$srvdb="localhost";
$usrdb="spysec";
$passdb="6u#roxe3L2u3oGUml2ij";
$db="spysec";

?>
