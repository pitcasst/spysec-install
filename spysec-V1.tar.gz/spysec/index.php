<!DOCTYPE html>
<html>
	<head>
		<title>Conessis</title>
		<meta charset="utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
			
		<link rel="stylesheet" href="css/bsc.css">
		<link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
		<link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
		<link rel="stylesheet" href="dist/css/AdminLTE.min.css">

		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">

		<script src="bower_components/jquery/dist/jquery.min.js"></script>
		<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
		<script src="bower_components/fastclick/lib/fastclick.js"></script> 
		<script src="dist/js/adminlte.min.js"></script>
		
			
		<?php session_start(); if(isset($_SESSION['id'])){ ?>
	</head>	
		<meta http-equiv="refresh" content="0; url=sub-paginas/pagina1.php">
	<?php } else { ?>
	<body class="hold-transition">	 
		<div class="login-box">
			<div class="login-logo">
				<a href="index.php"><b>SPY</b>SEC</a>
			</div>
			<div class="login-box-body">
				<p class="login-box-msg">Inicia sesión para comenzar tu sesión</p>
				<form action="php/login.php" method="post" class="form-horizontal">
					<div for="usr"class="form-group has-feedback">
						<input type="text" class="form-control" name="usr" placeholder="Usuario" required>
						<span class="glyphicon glyphicon-user form-control-feedback"></span>
					</div>
					<div for="pas"class="form-group has-feedback">
						<input type="password" class="form-control" name="pas" placeholder="Password" required>
						<span class="glyphicon glyphicon-lock form-control-feedback"></span>
					</div>
					<div class="row">
						<div class="col-xs-4">
							<button type="submit" class="btn btn-primary btn-flat">Inicia Sesión</button>
						</div>
					</div>
				</form>
			</div>
			<?php  ?>
		</div> 
	</body>
	<?php } ?>
</html>
