<!DOCTYPE html>
<html>
	<head>
		<title>Conessis</title>
		<meta charset="utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
			
		<link rel="stylesheet" href="css/bsc.css">
		<link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
		<link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
		<link rel="stylesheet" href="dist/css/AdminLTE.min.css">
		<link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
		<link rel="stylesheet" href="bower_components/morris.js/morris.css">
		<link rel="stylesheet" href="bower_components/jvectormap/jquery-jvectormap.css">
		<link rel="stylesheet" href="bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">
		<link rel="stylesheet" href="bower_components/bootstrap-daterangepicker/daterangepicker.css">
		<link rel="stylesheet" href="bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
			
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
		
		<script src="bower_components/jquery/dist/jquery.min.js"></script>
		<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
		<script src="bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
		<script src="bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
		<script src="bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
		<script src="bower_components/fastclick/lib/fastclick.js"></script>
		<script src="dist/js/adminlte.min.js"></script>
		<script src="dist/js/demo.js"></script>
		
		<?php include 'php/variables.php'; include "php/menu.php"; if($dbstanew == 1){ if($dbact == 1){ if($dblck == 0){ ?>
	
	</head>	
	<body class="hold-transition <?php echo $dbthm ?> layout-boxed sidebar-mini">
		<div class="wrapper">	
			<header class="main-header">
				<a href="#" class="logo">
					<span class="logo-mini"><b>S</b>S</span>
					<span class="logo-lg"><b>SPY</b>SEC</a>
				</a>
				<nav class="navbar navbar-static-top">
					<a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</a>
		      </a>
			  <div class="navbar-custom-menu">
				  <ul class="nav navbar-nav">
					  <li class="dropdown user user-menu">
					  <a href="#" class="dropdown-toggle" data-toggle="dropdown">
						  <img src="img/<?php echo $dbimg ?>" class="user-image" alt="User Image">
						  <span class="hidden-xs"><?php echo $dbnmb.' '.$dbape ?></span>
					  </a>
					  <ul class="dropdown-menu">
						  <li class="user-header">
						  <img src="img/<?php echo $dbimg ?>" class="img-circle" alt="User Image">
						  <p>
							  <?php echo $dbnmb.' '.$dbape ?> 
							  <small><?php echo $dbpue ?></small>
							  <small><?php echo $dbema ?></small>
						  </p>
						  </li>
						  <li class="user-body hidden">
						  <div class="row">
							  <div class="col-xs-4 text-center">
								  <a href="#">Followers</a>
							  </div>
							  <div class="col-xs-4 text-center">
								  <a href="#">Sales</a>
							  </div>
							  <div class="col-xs-4 text-center">
								  <a href="#">Friends</a>
							  </div>
						  </div> 
						  </li>
						  <li class="user-footer">
						  <div class="pull-left">
							  <a href="?section=<?php echo base64_encode('pagina10.php') ?>" class="btn btn-default btn-flat">Perfil</a>
						  </div>
						  <div class="pull-right">
							  <a href="php/logout.php" class="btn btn-default btn-flat">Salir</a>
						  </div>
						  </li>
					  </ul>
					  </li>
					  <li class="hidden">
					  	<a href="#" data-toggle="push-menu"><i class="fa fa-gears "></i></a>
					  </li>
				  </ul>
			  </div>
			</header>
			
			<aside class="main-sidebar">
				<section class="sidebar">
					<div class="user-panel">
						<div class="pull-left image">
							<img src="img/<?php echo $dbimg ?>" class="img-circle" alt="User Image">
						</div>
						<div class="pull-left info">
							<p><?php echo $dbnmb.' '.$dbape ?></p><?php if($dbstanew == 1){ ?><a href="#"><i class="fa fa-circle text-success"></i> Online</a><?php } else { ?><a href="#"><i class="fa fa-circle text-danger"></i> Offline</a><?php } ?>
						</div>
					</div>
					<ul class="sidebar-menu" data-widget="tree">
						<li class="header">MENÚ</li>
						<li<?php echo $dashboard  ?>><a href="?section=<?php echo base64_encode('dashboard.php') ?>"><i class="fa fa-dashboard"></i><span>Dashboard</span></span></a></li>
						<li<?php echo $pagina1  ?>><a href="?section=<?php echo base64_encode('pagina1.php') ?>"><i class="fa fa-file"></i><span>Pagina 1</span></span></a></li>
						<li class="treeview <?php echo $submen ?> ">
							<a href="#">
								<i class="fa fa-files-o"></i><span>Sub Menu</span>
								<span class="pull-right-container">
									<i class="fa fa-angle-left pull-right"></i>
								</span>
							</a>
							<ul class="treeview-menu">
								<?php if($dbper == 1 || $dbper == 2){ ?>
								<li<?php echo $pagina2 ?>><a href="?section=<?php echo base64_encode('pagina2.php') ?>"><i class="fa fa-file"></i><span>Pagina 2</span></span></a></li>
								<?php } ?>
								<li<?php echo $pagina3 ?>><a href="?section=<?php echo base64_encode('pagina3.php') ?>"><i class="fa fa-file"></i><span>Pagina 3</span></span></a></li>
								<li<?php echo $pagina4 ?>><a href="?section=<?php echo base64_encode('pagina4.php') ?>"><i class="fa fa-file"></i><span>Pagina 4</span></span></a></li>
								<?php if($dbper == 1 || $dbper == 2){ ?>
								<li<?php echo $pagina5 ?>><a href="?section=<?php echo base64_encode('pagina5.php') ?>"><i class="fa fa-file"></i><span>Pagina 5</span></span></a></li>
								<?php } ?>
							</ul>
						</li>
						<?php if($dbper == 1 || $dbper == 2){ ?>
						<li<?php echo $pagina6 ?>><a href="?section=<?php echo base64_encode('pagina6.php') ?>"><i class="fa fa-file"></i><span>Pagina 6</span></span></a></li>
						<?php } ?>
						<li<?php echo $pagina7 ?>><a href="?section=<?php echo base64_encode('pagina7.php') ?>"><i class="fa fa-file"></i><span>Pagina 7</span></span></a></li>						
						<li<?php echo $pagina8 ?>><a href="?section=<?php echo base64_encode('pagina8.php') ?>"><i class="fa fa-file"></i><span>Pagina 8</span></span></a></li>
						<?php if($dbper == 1){ ?>
						<li<?php echo $pagina9 ?>><a href="?section=<?php echo base64_encode('pagina9.php') ?>"><i class="fa fa-file"></i><span>Pagina 9</span></span></a></li>
						<?php } ?>
					</ul>
				</section>
			</aside>
			
			<div class="content-wrapper">
		    	<?php include "sub-paginas/".base64_decode($page) ?>
		    	
			</div>
			
			<footer class="main-footer">
		    	<div class="pull-right hidden-xs">
			    	<b>Version</b> 2.0
		    	</div>
				<strong>Copyright &copy; <?php echo $d=date("Y") ?></strong>
			</footer>
		</div>
		<?php } else { echo '<meta http-equiv="refresh" content="0; url=bloqueado.php">'; } } else { echo '<meta http-equiv="refresh" content="0; url=inactivo.php">'; } } else { echo '<meta http-equiv="refresh" content="0; url=index.php">'; } ?>
	</body>
	
</html>
