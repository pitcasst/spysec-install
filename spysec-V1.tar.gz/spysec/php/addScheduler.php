<?php
		include '../inc/inc_db.php';
		include 'variables.php';
		
		#$db=mysqli_connect($srvdb,$usrdb,$passdb,$db);
		
		//VARIABLES
		$nom=$_POST['nom'];
		$timeStart=$_POST['timeStat'];
		$timeEnd=$_POST['timeEnd'];
		$dia0=$_POST['dia0'];
		$dia1=$_POST['dia1'];
		$dia2=$_POST['dia2'];
		$dia3=$_POST['dia3'];
		$dia4=$_POST['dia4'];
		$dia5=$_POST['dia5'];
		$dia6=$_POST['dia6'];
		$logfch=date("Y-m-d H:i:s");
		
		//DIAS
		if($dia0 == ""){ $d0=""; } elseif($dia1 == "LU" || $dia2 == "MA" || $dia3 == "MI" || $dia4 == "JU" || $dia5 == "VI" || $dia6 == "SA") { $d0="0,"; } elseif($dia0 == "DM") { $d0="0"; }
		if($dia1 == ""){ $d1=""; } elseif($dia0 == "DO" || $dia2 == "MA" || $dia3 == "MI" || $dia4 == "JU" || $dia5 == "VI" || $dia6 == "SA") { $d1="1,"; } elseif($dia1 == "LU") { $d1="1"; }
		if($dia2 == ""){ $d2=""; } elseif($dia0 == "DO" || $dia1 == "LU" || $dia3 == "MI" || $dia4 == "JU" || $dia5 == "VI" || $dia6 == "SA") { $d2="2,"; } elseif($dia1 == "MA") { $d2="2"; }
		if($dia3 == ""){ $d3=""; } elseif($dia0 == "DO" || $dia1 == "LU" || $dia2 == "MA" || $dia4 == "JU" || $dia5 == "VI" || $dia6 == "SA") { $d3="3,"; } elseif($dia3 == "MI") { $d3="3"; }
		if($dia4 == ""){ $d4=""; } elseif($dia0 == "DO" || $dia1 == "LU" || $dia2 == "MA" || $dia3 == "MI" || $dia5 == "VI" || $dia6 == "SA") { $d4="4,"; } elseif($dia4 == "JU") { $d4="4"; }
		if($dia5 == ""){ $d5=""; } elseif($dia0 == "DO" || $dia1 == "LU" || $dia2 == "MA" || $dia3 == "MI" || $dia4 == "JU" || $dia6 == "SA") { $d5="5,"; } elseif($dia5 == "VI") { $d5="5"; }
		if($dia6 == ""){ $d6=""; } elseif($dia0 == "DO" || $dia1 == "LU" || $dia2 == "MA" || $dia3 == "MI" || $dia4 == "JU" || $dia6 == "VI") { $d6="6"; } elseif($dia6 == "SA") { $d6="6"; }			
				
		$dias=$d0.$d1.$d2.$d3.$d4.$d5.$d6;
		
		//HORARIOS
		$var1=explode(":",$timeStart);
		$valor1=$var1[0];
		$valor12=$var1[1];
		$hs=substr($valor1,1);
		$pmv1=substr($valor12,3);
		
		$var2=explode(":",$timeEnd);
		$valor2=$var2[0];
		$valor22=$var2[1];		
		$hf=substr($valor2,1);
		$pm=substr($valor22,3);
		
		if($pmv1 == "PM" && $hs =="1"){ $nwhs="13"; }
		elseif($pmv1 == "PM" && $hs == "2"){ $nwhs="14"; }
		elseif($pmv1 == "PM" && $hs == "3"){ $nwhs="15"; }
		elseif($pmv1 == "PM" && $hs == "4"){ $nwhs="16"; }
		elseif($pmv1 == "PM" && $hs == "5"){ $nwhs="17"; }
		elseif($pmv1 == "PM" && $hs == "6"){ $nwhs="18"; }
		elseif($pmv1 == "PM" && $hs == "7"){ $nwhs="19"; }
		elseif($pmv1 == "PM" && $hs == "8"){ $nwhs="20"; }
		elseif($pmv1 == "PM" && $hs == "9"){ $nwhs="21"; }
		elseif($pmv1 == "PM" && $hs == "10"){ $nwhs="22"; }
		elseif($pmv1 == "PM" && $hs == "11"){ $nwhs="23"; }
		elseif($pmv1 == "PM" && $hs == "12"){ $nwhs="0"; } else { $nwhs=$hs; }

		if($pm == "PM" && $hf =="1"){ $nwhf="13"; }
		elseif($pm == "PM" && $hf == "2"){ $nwhf="14"; }
		elseif($pm == "PM" && $hf == "3"){ $nwhf="15"; }
		elseif($pm == "PM" && $hf == "4"){ $nwhf="16"; }
		elseif($pm == "PM" && $hf == "5"){ $nwhf="17"; }
		elseif($pm == "PM" && $hf == "6"){ $nwhf="18"; }
		elseif($pm == "PM" && $hf == "7"){ $nwhf="19"; }
		elseif($pm == "PM" && $hf == "8"){ $nwhf="20"; }
		elseif($pm == "PM" && $hf == "9"){ $nwhf="21"; }
		elseif($pm == "PM" && $hf == "10"){ $nwhf="22"; }
		elseif($pm == "PM" && $hf == "11"){ $nwhf="23"; }
		elseif($pm == "PM" && $hf == "12"){ $nwhf="0"; } else { $nwhf=$hf; }
		
		$addUser_sql="INSERT INTO planificacion (nombre,hora_inicio,hora_fin,dia_semana_0,dia_semana_1,dia_semana_2,dia_semana_3,dia_semana_4,dia_semana_5,dia_semana_6) VALUES ('".$nom."','".$timeStart."','".$timeEnd."','".$dia0."','".$dia1."','".$dia2."','".$dia3."','".$dia4."','".$dia5."','".$dia6."')";
		$addUser_res=mysqli_query($db, $addUser_sql); 
		
		$logSpy_sql="INSERT INTO  logSpysec (fechaEvento,usuario,accion,ipHost) VALUES ('".$logfch."','".$dbusr."','agrego tarea: ".$nom."','".$ipHost."')";
		$logSpy_res=mysqli_query($db, $logSpy_sql);
		
		mysqli_close($db);
		
		$arcsal=fopen('./root',"a+");
		$cronstitle1="#---------";
		$cronstitle2="### Inicio ".$nom;
		$crons="* ".$nwhs." * * ".$dias." php /start";
		$cronftitle="#### Fin ".$nom;
		$cronf="* ".$nwhf." * * ".$dias." php /end";		
		fwrite($arcsal,$cronstitle1."\n");
		fwrite($arcsal,$cronstitle2."\n");		
		fwrite($arcsal,$crons."\n");		
		fwrite($arcsal,$cronftitle."\n");
		fwrite($arcsal,$cronf."\n");
		fclose($arcsal);
?>
