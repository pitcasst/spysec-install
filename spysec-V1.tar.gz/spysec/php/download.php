<?php
	include '../inc/inc_db.php'; include 'variables.php'; if($dbstanew == 1){ if($dbact == 1){ if($dblck == 0){ if($dbper == 1 || $dbper == 2){
			
	if(!empty($_GET['file'])){
    	$fileName = basename($_GET['file']);
		$filePath = '/var/spool/spysec/'.$fileName;
			if(!empty($fileName) && file_exists($filePath)){
			
				// Define headers
				#header("Cache-Control: public");
				#header("Content-Description: File Transfer");
				header("Content-Disposition: attachment; filename=$fileName");
				header("Content-Type: audio/x-wav");
				header("Content-Transfer-Encoding: binary");
	        
				// Read the file
				readfile($filePath);
				
				$logfch=date("Y-m-d H:i:s");
				
				$logSpy_sql2="INSERT INTO  logSpysec (fechaEvento,usuario,accion,ipHost) VALUES ('".$logfch."','".$dbusr."','descargo audio: ".$fileName."','".$ipHost."')";
				$logSpy_res2=mysqli_query($db, $logSpy_sql2);
				
				mysqli_close($db);
				
				exit;
    		} else {
	    		
	    		$logfch=date("Y-m-d H:i:s");
	    		
	    		$logSpy_sql2="INSERT INTO  logSpysec (fechaEvento,usuario,accion,ipHost) VALUES ('".$logfch."','".$dbusr."','el audio no existe','".$ipHost."')";
				$logSpy_res2=mysqli_query($db, $logSpy_sql2);
				
				mysqli_close($db);
        ?>
    <html>
		<head>
			<title>Conessis</title>
			<meta charset="utf-8" />
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
			<meta http-equiv="refresh" content="5; url=../sub-paginas/pagina1.php">
				
			<link rel="stylesheet" href="../css/bsc.css">
			<link rel="stylesheet" href="../bower_components/bootstrap/dist/css/bootstrap.min.css">
			<link rel="stylesheet" href="../bower_components/font-awesome/css/font-awesome.min.css">
			<link rel="stylesheet" href="../bower_components/Ionicons/css/ionicons.min.css">
			<link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
	
			<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
	
			<script src="../bower_components/jquery/dist/jquery.min.js"></script>
			<script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
			<script src="../bower_components/fastclick/lib/fastclick.js"></script> 
			<script src="../dist/js/adminlte.min.js"></script>
			
		</head>	
		<body class="hold-transition register-page">
			<div class="register-box">
				<section class="content">
					<div class="box box-default">
						<div class="box-body box-prodefile">
							<img class="img-responsive profile-user-img img-circle" src="../img/136549.svg" alt="User profile picture">
							<p></p>
							<p class="text-muted text-center"><?php echo $fileName ?></p>
							<ul class="list-group list-group-unbordered">
								<li class="list-group-item text-center">
									<b>El archivo no existe.</b>
								</li>
							</ul>
						</div>
					</div>
	    		</section>
			</div>
				
		</body>
	</html>
        
    <?php }
}
?>

<?php } else { ?>
	<html>
		<head>
			<title>Conessis</title>
			<meta charset="utf-8" />
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
			<meta http-equiv="refresh" content="5; url=../sub-paginas/pagina1.php">
				
			<link rel="stylesheet" href="../css/bsc.css">
			<link rel="stylesheet" href="../bower_components/bootstrap/dist/css/bootstrap.min.css">
			<link rel="stylesheet" href="../bower_components/font-awesome/css/font-awesome.min.css">
			<link rel="stylesheet" href="../bower_components/Ionicons/css/ionicons.min.css">
			<link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
	
			<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
	
			<script src="../bower_components/jquery/dist/jquery.min.js"></script>
			<script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
			<script src="../bower_components/fastclick/lib/fastclick.js"></script> 
			<script src="../dist/js/adminlte.min.js"></script>
			
		</head>	
		<body class="hold-transition register-page">			
			<div class="register-box">
				<section class="content">
					<div class="callout callout-warning">
						<h4>ALERTA!</h4><h4>Acceso no autorizado</h4>
						<p>Usted no tiene permisos para abrir esta pagina.</p>
					</div>
					<div class="row">
					<div class="col-xs-12">
					</div>
					</div>
				</section>
<?php } } else { echo '<meta http-equiv="refresh" content="0; url=../bloqueado.php">'; } } else { echo '<meta http-equiv="refresh" content="0; url=../inactivo.php">'; } } else { echo '<meta http-equiv="refresh" content="0; url=../index.php">'; }?>