<?php
		
	include '../inc/inc_db.php';
		
	$db=mysqli_connect($srvdb,$usrdb,$passdb,$db);
	
	$id=$_POST['id'];
	 
	$getUser_sql="SELECT * FROM audios WHERE id = '".$id."'";
	$getUser_res=mysqli_query($db, $getUser_sql); 
	
	$response = array();
	if(mysqli_num_rows($getUser_res) > 0) {
        while ($row = mysqli_fetch_assoc($getUser_res)) {
            	$response = $row;
        	}
    	}
		else
		{
        	$response['status'] = 200;
			$response['message'] = "Data not found!";
    	}

		echo json_encode($response);
		
		mysqli_close($db);
?>