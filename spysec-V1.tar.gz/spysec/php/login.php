<?php
	session_start();
	
	include '../inc/inc_db.php';
	
	$usrPOST=$_POST['usr'];
	$pasPOST=$_POST['pas'];
		
	$cont=0;
	$dbfchses=date("Y-m-d H:i:s");
	$ipHost=$_SERVER['REMOTE_ADDR'];

	$db=mysqli_connect($srvdb,$usrdb,$passdb,$db);
	$log_sql1="SELECT * FROM usuarios";
	$log_res1=mysqli_query($db, $log_sql1);
	while($row=mysqli_fetch_array($log_res1)){
		
		$dbid=	$row['id'];
		$dbusr=	$row['usuario'];
		$dbpas=	$row['contrasena'];

		if($usrPOST == $dbusr && md5($pasPOST) == $dbpas){
				
				$log_sql2="UPDATE usuarios SET status=1 WHERE id='".$dbid."'";
				$log_res2=mysqli_query($db, $log_sql2);
					
				$cont++;
				
				$_SESSION['id']=			$dbid;
				$_SESSION['usuario']=		$dbusr;
				$_SESSION['contrasena']=	$dbpas;
				$_SESSION['fecha_session']= $dbfchses;
				$_SESSION['ipHost']= 		$ipHost;
				
				$logSpy_sql="INSERT INTO logSpysec VALUES ('','','".$dbfchses."','".$usrPOST."','inicia sesion','','".$ipHost."','')";
				$logSpy_res=mysqli_query($db, $logSpy_sql); 				
			
			} else {
				$logSpy_sql="INSERT INTO logSpysec VALUES ('','','".$dbfchses."','".$usrPOST."','error al iniciar sesion','','".$ipHost."','')";
				$logSpy_res=mysqli_query($db, $logSpy_sql); 				
			}
			

		} 			
		
		mysqli_close($db);
?> 
		<meta http-equiv="refresh" content="0; url=../sub-paginas/pagina1.php">
<?php
		if($cont == 0){
	?>
			<meta http-equiv="refresh" content="0; url=../index.php">
<?php 			
			$wrong='
			<div class="box-body">
				<div class="alert alert-danger alert-dismissible">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
					Usuario o contraseña incorrecta.
				</div>
			</div>
			';
			
			$_SESSION['error']=$wrong;
		}
	?>				
