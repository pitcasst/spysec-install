<?php
	
	session_start();
	include '../inc/inc_db.php';
	
	$ses_id=		$_SESSION['id'];
	$ses_usr=		$_SESSION['usuario'];
	$ses_pas=		$_SESSION['contrasena'];
	$ses_fch=		$_SESSION['fecha_session'];
	$ipHost=		$_SERVER['REMOTE_ADDR'];
	
	$logfch=date("Y-m-d H:i:s");
	
	$db=mysqli_connect($srvdb,$usrdb,$passdb,$db);
	$out_sql="UPDATE usuarios SET status=0, fecha_session='".$ses_fch."' WHERE id='".$ses_id."'";
	$out_res=mysqli_query($db, $out_sql);
	
	$logSpy_sql="INSERT INTO  logSpysec (fechaEvento,usuario,accion,ipHost) VALUES ('".$logfch."','".$ses_usr."','cierra sesion','".$ipHost."')";
	$logSpy_res=mysqli_query($db, $logSpy_sql);
	
	session_destroy();
	mysqli_close($db)
	
	?>
	<meta http-equiv="refresh" content="0; url=../index.php">