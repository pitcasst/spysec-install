<?php 
		
	$ses_id="";			
	$submen="";			
	$dashboard="";		
	$pagina1="";		
	$pagina2="";		
	$pagina3="";		
	$pagina4="";		
	$pagina5="";		
	$pagina6="";		
	$pagina7="";		
	$pagina8="";		
	$pagina9="";
	$pagina10="";	
	
	
	if(isset($_GET['section'])){
		if(
		$_GET['section'] == base64_encode('pagina1.php') ||
		$_GET['section'] == base64_encode('pagina2.php') ||
		$_GET['section'] == base64_encode('pagina3.php') ||
		$_GET['section'] == base64_encode('pagina4.php') ||
		$_GET['section'] == base64_encode('pagina5.php') ||
		$_GET['section'] == base64_encode('pagina6.php') ||
		$_GET['section'] == base64_encode('pagina7.php') ||
		$_GET['section'] == base64_encode('pagina8.php') ||
		$_GET['section'] == base64_encode('pagina9.php') ||
		$_GET['section'] == base64_encode('pagina10.php') ||
		$_GET['section'] == base64_encode('dashboard.php')
		){
			$page=$_GET['section'];
		} else {
			if($dbper == 1){ #|| $usrper="2"){
				$page=base64_encode('pagina1.php');	
			} else {
				$page=base64_encode('pagina1.php');
			}
		}
	} else {
		if($dbper == 1){ #|| $usrper="2"){
			$page=base64_encode('pagina1.php');
		} else {
			$page=base64_encode('pagina1.php');
		}
	}
	
	if(isset($_GET['section'])){
		if($_GET['section'] == base64_encode("dashboard.php")){
				$submen="";
				$dashboard=' class="active"';					
		} elseif ($_GET['section'] == base64_encode('pagina1.php')) {
				$submen="";
				$pagina1=' class="active"';
		} elseif ($_GET['section'] == base64_encode('pagina2.php')) {
				$submen="active";
				$pagina2=' class="active"';
		} elseif ($_GET['section'] == base64_encode('pagina3.php')) {
				$submen="active";
				$pagina3=' class="active"';
		} elseif ($_GET['section'] == base64_encode('pagina4.php')) {
				$submen="active";
				$pagina4=' class="active"';
		} elseif ($_GET['section'] == base64_encode('pagina5.php')) {
				$submen="active";
				$pagina5=' class="active"';
		} elseif ($_GET['section'] == base64_encode('pagina6.php')) {
				$submen="";
				$pagina6=' class="active"';
		} elseif ($_GET['section'] == base64_encode('pagina7.php')) {
				$submen="";
				$pagina7=' class="active"';
		} elseif ($_GET['section'] == base64_encode('pagina8.php')) {
				$submen="";
				$pagina8=' class="active"';
		} elseif ($_GET['section'] == base64_encode('pagina9.php')) {
				$submen="";
				$pagina9=' class="active"';
		} elseif ($_GET['section'] == base64_encode('pagina10.php')) {
				$submen="";
				$pagina10="";
		}
	} else {
		$submen="";
		$dashboard='class="active"';
	}
	?>
