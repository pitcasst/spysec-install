<?php

	include '../inc/inc_db.php';
	include 'variables.php';
		
	#$db=mysqli_connect($srvdb,$usrdb,$passdb,$db);
		
	$id=$_POST['id'];
    $pass=$_POST['pass'];
    $logfch=date("Y-m-d H:i:s");
    
    $edtpassUser_sql = "UPDATE usuarios SET contrasena='".md5($pass)."' WHERE id='".$id."'";
    $edtpassUser_res = mysqli_query($db, $edtpassUser_sql);
    
    $query_res=str_replace("'","",$edtpassUser_sql);
    
    $logSpy_sql1="SELECT usuario FROM usuarios WHERE id ='".$id."'";
	$logSpy_res1=mysqli_query($db, $logSpy_sql1);
	$logSpy_res1_row=mysqli_fetch_array($logSpy_res1);
    
    $logSpy_sql2="INSERT INTO  logSpysec (fechaEvento,usuario,accion,query,ipHost) VALUES ('".$logfch."','".$dbusr."','modifico contraseña de usuario: ".$logSpy_res1_row[0]."','".$query_res."','".$ipHost."')";
	$logSpy_res2=mysqli_query($db, $logSpy_sql2);
	
	mysqli_close($db);
	
?>