<?php
	
	include '../inc/inc_db.php';
	include 'variables.php';
			
	#$db=mysqli_connect($srvdb,$usrdb,$passdb,$db);
		
	$id=$_POST['id'];
		
	$stopSch_sql="UPDATE planificacion SET estado='1' WHERE id = '".$id."'";
	$stopSch_res=mysqli_query($db, $stopSch_sql);
	
	$logSpy_sql1="SELECT nombre FROM planificacion WHERE id ='".$id."'";
	$logSpy_res1=mysqli_query($db, $logSpy_sql1);
	$logSpy_res1_row=mysqli_fetch_array($logSpy_res1);
	
	$logSpy_sql2="INSERT INTO logSpysec VALUES ('','','".$dbfchses."','".$dbusr."','inicio tarea: ".$logSpy_res1_row[0]."','','".$ipHost."','')";
	$logSpy_res2=mysqli_query($db, $logSpy_sql2);
	
	mysqli_close($db);
?>