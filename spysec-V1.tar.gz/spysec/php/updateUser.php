<?php

	include '../inc/inc_db.php';
	include 'variables.php';
		
	#$db=mysqli_connect($srvdb,$usrdb,$passdb,$db);
		
	$id=$_POST['id'];
    $usr=$_POST['usr'];
	$nom=$_POST['nom'];
	$ape=$_POST['ape'];
	$pue=$_POST['pue'];
	$eml=$_POST['eml'];
	$logfch=date("Y-m-d H:i:s");

    $editUser_sql = "UPDATE usuarios SET nombre='".$nom."',apellido='".$ape."',puesto='".$pue."',email='".$eml."' WHERE id='".$id."'";
    $editUser_res = mysqli_query($db, $editUser_sql);
    
    $query_res=str_replace("'","",$editUser_sql);
	
	$logSpy_sql2="INSERT INTO  logSpysec (fechaEvento,usuario,accion,query,ipHost) VALUES ('".$logfch."','".$dbusr."','modifico usuario: ".$usr."','".$query_res."','".$ipHost."')";
	$logSpy_res2=mysqli_query($db, $logSpy_sql2);
	
	mysqli_close($db);

?>