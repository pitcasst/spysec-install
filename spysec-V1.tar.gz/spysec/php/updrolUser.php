<?php

	include '../inc/inc_db.php';
	include 'variables.php';
		
	#$db=mysqli_connect($srvdb,$usrdb,$passdb,$db);
		
	$id=$_POST['id'];
    $rol=$_POST['rol'];
    $logfch=date("Y-m-d H:i:s");
    
    $edtrolUser_sql = "UPDATE usuarios SET perfil='".$rol."' WHERE id='".$id."'";
    $edtrolUser_res = mysqli_query($db, $edtrolUser_sql);
    
    $query_res=str_replace("'","",$edtrolUser_sql);
    
    $logSpy_sql1="SELECT usuario FROM usuarios WHERE id ='".$id."'";
	$logSpy_res1=mysqli_query($db, $logSpy_sql1);
	$logSpy_res1_row=mysqli_fetch_array($logSpy_res1);
    
    $logSpy_sql2="INSERT INTO  logSpysec (fechaEvento,usuario,accion,query,ipHost) VALUES ('".$logfch."','".$dbusr."','modifico perfil de usuario: ".$logSpy_res1_row[0]."','".$query_res."','".$ipHost."')";
	$logSpy_res2=mysqli_query($db, $logSpy_sql2);
	
	mysqli_close($db);
?>