<?php
	
	session_start();
				
	#include '../inc/inc_db.php';
				
	$ses_id=		$_SESSION['id'];
	$ses_usr=		$_SESSION['usuario'];
	$ses_pas=		$_SESSION['contrasena'];
	$ipHost=		$_SESSION['ipHost'];
	

	$db=mysqli_connect($srvdb,$usrdb,$passdb,$db);
	$var_sql="SELECT * FROM usuarios WHERE id='".$ses_id."'";
	$var_res=mysqli_query($db, $var_sql);
	
	while($row=mysqli_fetch_array($var_res)){
		
		$dbid=$row['id'];
		$dbusr=$row['usuario'];
		$dbpas=$row['contrasena'];
		$dbnmb=$row['nombre'];
		$dbape=$row['apellido'];
		$dbpue=$row['puesto'];
		$dbema=$row['email'];
		$dbimg=$row['img'];
		$dbstanew=$row['status'];
		$dbper=$row['perfil'];
		$dbgpo=$row['grupo'];
		$dbthm=$row['tema'];
		$dbact=$row['activo'];
		$dblck=$row['bloqueado'];
		$dbfchreg=$row['fecha_registro'];
		$dbfchses=$row['fecha_session'];
	}	
	
	?>
	
