<?php
	
	include '../inc/inc_db.php';
	include 'variables.php';
		
	#$db=mysqli_connect($srvdb,$usrdb,$passdb,$db);
		
	$usr=$_POST['usr'];
	$pas=$_POST['pas'];
	$nom=$_POST['nom'];
	$ape=$_POST['ape'];
	$pue=$_POST['pue'];
	$eml=$_POST['eml'];
	$rol=$_POST['rol'];			
	$fchreg=date("Y-m-d H:m:s");
	$thema="skin-blue";
	$imagen="FullSizeRender.png";
		
	$addUser_sql="INSERT INTO usuarios VALUES ('','".$usr."','".md5($pas)."','".$nom."','".$ape."','".$pue."','".$eml."','".$imagen."','','".$rol."','".$thema."','1','','".$fchreg."','','','')";
	$addUser_res=mysqli_query($db, $addUser_sql); 
		
	$logSpy_sql2="INSERT INTO logSpysec VALUES ('','','".$dbfchses."','".$dbusr."','creo usuario: ".$usr."','','".$ipHost."','')";
	$logSpy_res2=mysqli_query($db, $logSpy_sql2);
	
	mysqli_close($db);
?>