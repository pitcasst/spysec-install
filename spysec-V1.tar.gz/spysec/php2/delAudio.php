<?php
	
	include '../inc/inc_db.php';
	include 'variables.php';
		
	#$db=mysqli_connect($srvdb,$usrdb,$passdb,$db);
		
	$id=$_POST['id'];
	
	$logSpy_sql1="SELECT audio FROM audios WHERE id ='".$id."'";
	$logSpy_res1=mysqli_query($db, $logSpy_sql1);
	$logSpy_res1_row=mysqli_fetch_array($logSpy_res1);
		
	$delAudio_sql="DELETE FROM audios WHERE id = '".$id."'";
	$delAudio_res=mysqli_query($db, $delAudio_sql);
	
	$logSpy_sql2="INSERT INTO logSpysec VALUES ('','','".$dbfchses."','".$dbusr."','eliminio audio: ".$logSpy_res1_row[0]."','','".$ipHost."','')";
	$logSpy_res2=mysqli_query($db, $logSpy_sql2);
	
	mysqli_close($db);	
?>