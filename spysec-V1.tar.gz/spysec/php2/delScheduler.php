<?php
	
	include '../inc/inc_db.php';
	include 'variables.php';
	
	#$db=mysqli_connect($srvdb,$usrdb,$passdb,$db);
	
	$id=$_POST['id'];	
	
	$logSpy_sql1="SELECT nombre FROM planificacion WHERE id ='".$id."'";
	$logSpy_res1=mysqli_query($db, $logSpy_sql1);
	$logSpy_res1_row=mysqli_fetch_array($logSpy_res1);
	
	$delUser_sql="DELETE FROM planificacion WHERE id ='".$id."'";
	$delUser_res=mysqli_query($db, $delUser_sql);
	
	$logSpy_sql2="INSERT INTO logSpysec VALUES ('','','".$dbfchses."','".$dbusr."','elimino tarea: ".$logSpy_res1_row[0]."','','".$ipHost."','')";
	$logSpy_res2=mysqli_query($db, $logSpy_sql2);
	
	mysqli_close($db);
?>