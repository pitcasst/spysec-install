<!DOCTYPE html>
<html>
	<head>
		<title>Conessis</title>
		<meta charset="utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
			
		<link rel="stylesheet" href="../css/bsc.css">
		<link rel="stylesheet" href="../bower_components/bootstrap/dist/css/bootstrap.min.css">
		<link rel="stylesheet" href="../bower_components/font-awesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="../bower_components/Ionicons/css/ionicons.min.css">
		<link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
		<link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">
		<link rel="stylesheet" href="../bower_components/morris.js/morris.css">
		<link rel="stylesheet" href="../bower_components/jvectormap/jquery-jvectormap.css">
		<link rel="stylesheet" href="../bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">
		<link rel="stylesheet" href="../bower_components/bootstrap-daterangepicker/daterangepicker.css">
		<link rel="stylesheet" href="../bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css"> 
		<link rel="stylesheet" href="../plugins/timepicker/bootstrap-timepicker.min.css">
		<link rel="stylesheet" href="../plugins/iCheck/all.css">
		<link rel="stylesheet" href="../bower_components/select2/dist/css/select2.min.css">
		<link rel="stylesheet" href="../skin/blue.monday/css/jplayer.blue.monday.min.css">
			
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
		
		<script src="../bower_components/jquery/dist/jquery.min.js"></script>
		<script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
		<script src="../bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
		<script src="../bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
		<script src="../bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
		<script src="../bower_components/fastclick/lib/fastclick.js"></script>
		<script src="../plugins/timepicker/bootstrap-timepicker.min.js"></script>
		<script src="../dist/js/adminlte.min.js"></script>
		<script src="../dist/js/demo.js"></script>
		<script src="../plugins/iCheck/icheck.min.js"></script>
		<script src="../js/jquery.jplayer.min.js"></script>
		
	</head>	
	<body class="hold-transition <?php echo $dbthm ?> layout-boxed sidebar-mini"> <!--layout-boxed-->
		<div class="wrapper">	
			<header class="main-header">
				<a href="#" class="logo">
					<span class="logo-mini"><b>S</b>S</span>
					<span class="logo-lg"><b>SPY</b>SEC</a>
				</a>
				<nav class="navbar navbar-static-top">
					<a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</a>
		      </a>
			  <div class="navbar-custom-menu">
				  <ul class="nav navbar-nav">
					  <li class="dropdown user user-menu">
					  <a href="#" class="dropdown-toggle" data-toggle="dropdown">
						  <img src="../img/<?php echo $dbimg ?>" class="user-image" alt="User Image">
						  <span class="hidden-xs"><?php echo $dbnmb.' '.$dbape ?></span>
					  </a>
					  <ul class="dropdown-menu">
						  <li class="user-header">
						  <img src="../img/<?php echo $dbimg ?>" class="img-circle" alt="User Image">
						  <p>
							  <?php echo $dbnmb.' '.$dbape ?> 
							  <small><?php echo $dbpue ?></small>
							  <small><?php echo $dbema ?></small>
						  </p>
						  </li>
						  <li class="user-body hidden">
						  <div class="row">
							  <div class="col-xs-4 text-center">
								  <a href="#">Followers</a>
							  </div>
							  <div class="col-xs-4 text-center">
								  <a href="#">Sales</a>
							  </div>
							  <div class="col-xs-4 text-center">
								  <a href="#">Friends</a>
							  </div>
						  </div> 
						  </li>
						  <li class="user-footer">
						 <!-- <div class="pull-left">
							  <a href="pagina10.php" class="btn btn-default btn-flat">Perfil</a>
						  </div> -->
						  <div class="pull-right">
							  <a href="../php/logout.php" class="btn btn-default btn-flat">Salir</a>
						  </div>
						  </li>
					  </ul>
					  </li>
					  <li class="hidden">
					  	<a href="#" data-toggle="push-menu"><i class="fa fa-gears "></i></a>
					  </li>
				  </ul>
			  </div>
			</header>
			
			<aside class="main-sidebar">
				<section class="sidebar">
					<div class="user-panel">
						<div class="pull-left image">
							<img src="../img/<?php echo $dbimg ?>" class="img-circle" alt="User Image">
						</div>
						<div class="pull-left info">
							<p><?php echo $dbnmb.' '.$dbape ?></p><?php if($dbstanew == 1){ ?><a href="#"><i class="fa fa-circle text-success"></i> Online</a><?php } else { ?><a href="#"><i class="fa fa-circle text-danger"></i> Offline</a><?php } ?>
						</div>
					</div>
						<ul class="sidebar-menu" data-widget="tree">
							<li class="header">MENÚ</li>
							<!-- <li<?php if($pagina == "dashboard"){?> class="active" <?php } ?>><a href="dashboard.php"><i class="fa fa-dashboard"></i><span>Dashboard</span></span></a></li> -->
							<li<?php if($pagina == "pagina1"){?> class="active" <?php } ?>><a href="pagina1.php"><i class="fa fa-volume-up"></i><span>Biblioteca</span></span></a></li>
							<?php if($dbper == 1 || $dbper == 2){ ?>
							<li<?php if($pagina == "pagina2"){?> class="active" <?php } ?>><a href="pagina2.php"><i class="fa fa-calendar"></i><span>Planificador</span></span></a></li>
							<?php } ?>
							<?php if($dbper == 1){ ?>
							<li class="treeview<?php if($pagina == "pagina3" || $pagina == "pagina4" || $pagina == "pagina5" || $pagina == "pagina6" || $pagina == "pagina9"){?> active <?php } ?>">
								<a href="#">
									<i class="fa fa-gears"></i><span>Administracion</span>
									<span class="pull-right-container">
										<i class="fa fa-angle-left pull-right"></i>
									</span>
								</a>
								<ul class="treeview-menu">
									<!-- <li<?php if($pagina == "pagina3"){?> class="active" <?php } ?>><a href="pagina3.php"><i class="fa fa-gear"></i><span>General</span></span></a></li> -->
									<!-- <li<?php if($pagina == "pagina4"){?> class="active" <?php } ?>><a href="pagina4.php"><i class="fa fa-globe"></i><span>Red</span></span></a></li>
									<li<?php if($pagina == "pagina5"){?> class="active" <?php } ?>><a href="pagina5.php"><i class="fa fa-chain"></i><span>Open VPN</span></span></a></li>
									<li<?php if($pagina == "pagina6"){?> class="active" <?php } ?>><a href="pagina6.php"><i class="fa fa-hdd-o"></i><span>Almacenamiento</span></span></a></li> -->
									<li<?php if($pagina == "pagina9"){?> class="active" <?php } ?>><a href="pagina9.php"><i class="fa fa-users"></i><span>Usuarios</span></span></a></li>
									<?php } ?>
								</ul>
							</li>
							<!--
							<li<?php if($pagina == "pagina6"){?> class="active" <?php } ?>><a href="pagina6.php"><i class="fa fa-file"></i><span>Pagina 6</span></span></a></li>
							<li<?php if($pagina == "pagina7"){?> class="active" <?php } ?>><a href="pagina7.php"><i class="fa fa-file"></i><span>Pagina 7</span></span></a></li>						
							<li<?php if($pagina == "pagina8"){?> class="active" <?php } ?>><a href="pagina8.php"><i class="fa fa-file"></i><span>Pagina 8</span></span></a></li>
							<li<?php if($pagina == "pagina9"){?> class="active" <?php } ?>><a href="pagina9.php"><i class="fa fa-users"></i><span>Usuarios</span></span></a></li> -->
						</ul>

				</section>
			</aside>
			<div class="content-wrapper">