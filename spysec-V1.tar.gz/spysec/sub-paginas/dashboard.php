<?php $pagina = pathinfo($_SERVER['PHP_SELF'], PATHINFO_FILENAME); include '../inc/inc_db.php'; include '../php/variables.php';if($dbstanew == 1){ if($dbact == 1){ if($dblck == 0){ include "cbz.php"; if($dbper == 1 || $dbper == 2 | $dbper == 3){ ?>

		<section class="content-header">
			<h1>
				Dashboard
				<small>Version 2.0</small>
			</h1>
			<ol class="breadcrumb">
				<li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
				<li class="active">Dashboard</li>
			</ol>
		</section>
		<section class="content">
			
			<div class="row">
				<div class="col-md-4">
					<div class="box box-solid">
						<div class="box-header with-border">
							<i class="fa fa-info"></i>
							<h3 class="box-title">Sistema</h3>
						</div>
						<div class="box-body">
							<div class="box-body text-center">
								<h4>Bienvenido a SPYSEC</h4>
							</div>	
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="box box-solid">
						<div class="box-header with-border">
							<i class="fa fa-info"></i>
							<h3 class="box-title">Tiempo activo</h3>
						</div>
						<div class="box-body">
							<div class="box-body text-center">
								<h4>Sistema reiniciado por última vez</h4>
							</div>
							<div class="box-body text-center">
								<h4>Load Averages</h4>
							</div>	
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="info-box bg-aqua">
						<span class="info-box-icon"><i class="ion ion-android-volume-up"></i></span>
						<div class="info-box-content">
							<span class="info-box-text">Audios</span>
							<span class="info-box-number">2</span>
							<div class="progress">
								<div class="progress-bar" style="width: 100%"></div>
							</div>
						</div>
					</div>
			</div>
			
		</section>
		
<?php } else { ?>
<section class="content">
	<div class="callout callout-warning">
		<h4>ALERTA!</h4><h4>Acceso no autorizado</h4>
		<p>Usted no tiene permisos para abrir esta pagina.</p>
	</div>
	<div class="row">
		<div class="col-xs-12">
		</div>
	</div>
</section>
<?php } ?>

<?php include "pie.php"; ?>
<?php } else { echo '<meta http-equiv="refresh" content="0; url=../bloqueado.php">'; } } else { echo '<meta http-equiv="refresh" content="0; url=../inactivo.php">'; } } else { echo '<meta http-equiv="refresh" content="0; url=../index.php">'; }?>