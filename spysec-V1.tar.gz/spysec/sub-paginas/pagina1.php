<?php $pagina = pathinfo($_SERVER['PHP_SELF'], PATHINFO_FILENAME); include '../inc/inc_db.php'; include '../php/variables.php';if($dbstanew == 1){ if($dbact == 1){ if($dblck == 0){ include "cbz.php"; if($dbper == 1 || $dbper == 2 || $dbper == 3){ 
	
	$rec_sql="SELECT * FROM audios";	
	$rec_res=mysqli_query($db, $rec_sql);
	
?>

		<section class="content-header">
			<h1>
				Biblioteca
				<small>Version 2.0</small>
			</h1>
			<ol class="breadcrumb">
				<li><a href="#"><i class="fa fa-dashboard"></i> Inicio</a></li>
				<li class="active">Biblioteca</li>
			</ol>
		</section>
		
			<section class="content">
				<div class="row">
					<div class="col-md-12">
						<div class="box box-primary">
							<div class="box-header with-border">
								<small class="pull-right"><?php echo $hoy=date("F j, Y, g:i a") ?></small>
							</div>
							<div class="box-body">
								<div class="table-responsive">
									<table id="example1" class="table table-condensed ">
										<thead>
											<tr>
												<th>Calldate</th>
												<th>File Name</th>
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
											<?php while($rec_row=mysqli_fetch_array($rec_res)){ ?>
											<tr>
												<td><?php echo $rec_row[1]; ?></td>
												<td><?php echo $rec_row[4]; ?></td>
												<td>
													<?php if( $dbper == 1 || $dbper ==  2){ ?>
													<a href="../php/download.php?file=<?php echo $rec_row[2]; ?>"><span class="glyphicon glyphicon-download"></span></a>&nbsp&nbsp
													<?php } ?>
													<a href="#"><span class="glyphicon glyphicon-play-circle" data-toggle="collapse" data-target="#<?php echo $rec_row[0]; ?>" ></span></a>&nbsp&nbsp
													<?php if( $dbper == 1 ){ ?>
													<a href="#" onClick="getAudio('<?php echo $rec_row[0]; ?>')"><span class="glyphicon glyphicon-remove-circle"></span></a>
													<?php } ?>
												</td>
											</tr>
											 <tr id="<?php echo $rec_row[0]; ?>" class="collapse">
												<td>
													<table>
														<tr>
															<td>	
																<?php $audio=file_get_contents('http://'.$_SERVER['SERVER_ADDR'].'/RECORDINGS/'.$rec_row[4].'.wav'); ?>
																<audio controls controlslist="nodownload"  src="data:audio/wav;base64, <?php echo base64_encode($audio) ?>">
																	The “audio” tag is not supported by your browser.
																</audio>				
															</td>
														</tr>
													</table>
												</td>
												<td class="hidden"><?php echo $rec_row[4]; ?></td>
												<td class="hidden"><?php echo $rec_row[4]; ?></td>
											</tr>
											<?php } mysqli_close($db); ?>
										</tbody>
										<tfoot>
											<tr>
												<th>Calldate</th>
												<th>Action</th>
												<th>File Name</th>
											</tr>
										</tfoot>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			
			<div class="modal fade" id="delAudio">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
							<h4 class="modal-title">Eliminar audio</h4>
						</div>
						<div class="modal-body">
							<img class="img-responsive profile-user-img img-circle" src="../img/136549.svg" alt="User profile picture">
							<p></p>
							<nomAudio class="text-muted text-center"></nomAudio>
							<div class="row">
								<div class="col-md-3"></div>
								<div class="col-md-6">
									<input type="id" id="nomAudio" value="" class="form-control text-center" disabled/>
									<input type="id" id="hidAudio_id" value="" class="form-control hidden"/>
								</div>
								<div class="col-md-3"></div>
							</div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default pull-rigth" data-dismiss="modal">Cancelar</button>
							<button onClick="delAudio()" class="btn btn-primary pull-rigth">Aceptar</button>
						</div>
					</div>
				</div>
			</div>
			
			<script>
			$(document).ready(function() {
				$('table.table-condensed').DataTable({
					"lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
					"order": [[ 1, 'asc' ]],
					"language": {
						"url": "../json/Spanish.json"
						}
					})
				;});
				
				//Audio
				function getAudio(id) {
					$("#hidAudio_id").val(id);
					$.post("../php/getAudio.php", {
						id: id	
						},
						function(data, status) {
							var user = JSON.parse(data);				
							$("#nomAudio").val(user.audio);
							}
						);
					$("#delAudio").modal("show");
					}
				
				//eliminar Audio
				function delAudio(){
					var id = $("#hidAudio_id").val();
					$.post("../php/delAudio.php", {
							id: id
						},
						function (data, status) {
							location. reload();
							}
						);
					}
					
			</script>
			
<?php } else { ?>
<section class="content">
	<div class="callout callout-warning">
		<h4>ALERTA!</h4><h4>Acceso no autorizado</h4>
		<p>Usted no tiene permisos para abrir esta pagina.</p>
	</div>
	<div class="row">
		<div class="col-xs-12">
		</div>
	</div>
</section>
		
<?php } ?>

<?php include "pie.php"; ?>
<?php } else { echo '<meta http-equiv="refresh" content="0; url=../bloqueado.php">'; } } else { echo '<meta http-equiv="refresh" content="0; url=../inactivo.php">'; } } else { echo '<meta http-equiv="refresh" content="0; url=../index.php">'; }?>
