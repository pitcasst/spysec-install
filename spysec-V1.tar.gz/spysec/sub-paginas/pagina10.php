<?php $pagina = pathinfo($_SERVER['PHP_SELF'], PATHINFO_FILENAME); include '../inc/inc_db.php'; include '../php/variables.php';if($dbstanew == 1){ if($dbact == 1){ if($dblck == 0){ include "cbz.php"; if($dbper == 1 || $dbper == 2 || $dbper == 3){ ?>

		<section class="content-header">
			<h1>
				Perfil
				<small>Version 2.0</small>
			</h1>
			<ol class="breadcrumb">
				<li><a href="#"><i class="fa fa-dashboard"></i> Inicio</a></li>
				<li class="active">Perfil</li>
			</ol>
		</section>
		
			<section class="content">
				<div class="row">
					<div class="col-md-3">
						<div class="box box-primary">
							<div class="box-body box-profile">
								<img class="profile-user-img img-responsive img-circle" src="../img/<?php echo $dbimg ?>" alt="User profile picture">
								<h3 class="profile-username text-center"><?php echo $dbnmb.' '.$dbape ?> </h3>
								<p class="text-muted text-center"><?php echo $dbpue ?></p>
								<ul class="list-group list-group-unbordered text-center">
									<li class="list-group-item">
										<b>Fecha de registro: </b>
										<p><?php echo $dbfchreg ?></p>
									</li>
									<li class="list-group-item">
										<b>Ultimo inicio de session: </b>
										<p><?php echo $dbfchses ?></p>
									</li>
									<li class="list-group-item hidden">
										<b>Grupo</b>
										<a class="pull-right">13,287</a>
									</li>
								</ul>
								<a href="#" class="btn btn-primary btn-block hidden"><b>Follow</b></a>
							</div>
						</div>
					</div>
					
					<div class="col-md-9">
						<div class="nav-tabs-custom">
							<ul class="nav nav-tabs">
								<li><a href="#tab_1" data-toggle="tab">General</a></li>
								<li class="active"><a href="#tab_2" data-toggle="tab">Contraseña</a></li>
								<li class="hidden"><a href="#tab_3" data-toggle="tab">Tab 3</a></li>
								<li class="hidden"><a href="#tab_3" data-toggle="tab">Tab 4</a></li>
								<li class="hidden"><a href="#tab_3" data-toggle="tab">Tab 5</a></li>
								<li class="pull-right">
									<div class="box-header">
										<small class="pull-right"><?php echo $hoy=date("F j, Y, g:i a") ?></small>
									</div>
								</li>
							</ul>
							<div class="tab-content">
								<div class="tab-pane" id="tab_1">
									<form class="form-horizontal">
										<h4>Editar información de usuario</h4>
										<div class="box-body">
											<div class="form-group">
												<label for="Usuario" class="col-sm-2 control-label">Usuario</label>
												<div class="col-sm-10">
													<input type="text" class="form-control" id="Usuario" placeholder="Usuario" value="<?php echo $dbusr ?>" disabled >
												</div>
											</div>
											<div class="form-group hidden">
												<label for="Password" class="col-sm-2 control-label">Contraseña</label>
												<div class="col-sm-10">
													<input type="password" class="form-control" id="Password" placeholder="Contraseña" value="<?php echo $dbpas ?>">
												</div>
											</div>
											<div class="form-group">
												<label for="Nombre" class="col-sm-2 control-label">Nombre(s)</label>
												<div class="col-sm-10">
													<input type="text" class="form-control" id="Nombre" placeholder="Nombre(s)" value="<?php echo $dbnmb ?>">
												</div>
											</div>
											<div class="form-group">
												<label for="Apellido" class="col-sm-2 control-label">Apellido(s)</label>
												<div class="col-sm-10">
													<input type="text" class="form-control" id="Apellido" placeholder="Apellido(s)" value="<?php echo $dbape ?>">
												</div>
											</div>
											<div class="form-group">
												<label for="Ocupacion" class="col-sm-2 control-label">Ocupacion</label>
												<div class="col-sm-10">
													<input type="text" class="form-control" id="Ocupacion" placeholder="Ocupacion" value="<?php echo $dbpue ?>">
												</div>
											</div>
											<div class="form-group">
												<label for="Email" class="col-sm-2 control-label">Email</label>
												<div class="col-sm-10">	
													<input type="email" class="form-control" id="Email" placeholder="Email" value="<?php echo $dbema ?>">
												</div>
											</div>
										</div>
										<div class="box-footer">
											<button type="submit" class="btn btn-info pull-right">Actualizar</button>
										</div>
									</form>
								</div>
								<div class="tab-pane active" id="tab_2">
									<form class="form-horizontal">
										<h4>Cambiar contraseña</h4>
										<div class="box-body">
											<div class="form-group">
												<label for="Password" class="col-sm-2 control-label">Contraseña actual</label>
												<div class="col-sm-10">
													<input type="password" class="form-control" id="PasswordOld" placeholder="Contraseña actual">
												</div>
											</div>
											<div class="form-group">
												<label for="Nombre" class="col-sm-2 control-label">Nueva contraseña </label>
												<div class="col-sm-10">
													<input type="password" class="form-control" id="PasswordNew" placeholder="Nueva contraseña">
												</div>
											</div>
											<div class="form-group">
												<label for="Apellido" class="col-sm-2 control-label">Confirmar contraseña </label>
												<div class="col-sm-10">
													<input type="password" class="form-control" id="PasswordNewRep" placeholder="Confirmar contraseña">
												</div>
											</div>
										</div>
										<div class="box-footer">
											<button type="submit" class="btn btn-info pull-right">Actualizar</button>
										</div>
									</form> 
								</div>
								<div class="tab-pane" id="tab_3">									
								</div>
								<div class="tab-pane" id="tab_4">	
								</div>
								<div class="tab-pane" id="tab_5">	
								</div>
							</div>
						</div>
					</div>	
        		</div>
			</section>
			
<?php } else { ?>
<section class="content">
	<div class="callout callout-warning">
		<h4>ALERTA!</h4><h4>Acceso no autorizado</h4>
		<p>Usted no tiene permisos para abrir esta pagina.</p>
	</div>
	<div class="row">
		<div class="col-xs-12">
		</div>
	</div>
</section>
<?php } ?>

<?php include "pie.php"; ?>
<?php } else { echo '<meta http-equiv="refresh" content="0; url=../bloqueado.php">'; } } else { echo '<meta http-equiv="refresh" content="0; url=../inactivo.php">'; } } else { echo '<meta http-equiv="refresh" content="0; url=../index.php">'; }?>
