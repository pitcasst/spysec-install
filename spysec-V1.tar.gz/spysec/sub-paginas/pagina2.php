<?php $pagina = pathinfo($_SERVER['PHP_SELF'], PATHINFO_FILENAME); include '../inc/inc_db.php'; include '../php/variables.php';if($dbstanew == 1){ if($dbact == 1){ if($dblck == 0){ include "cbz.php"; if($dbper == 1 || $dbper == 2 || $dbper == 3){
	$sch_sql="SELECT * FROM planificacion";	
	$sch_res=mysqli_query($db, $sch_sql);
?>

		<section class="content-header">
			<h1>
				Planificador
				<small>Version 2.0</small>
			</h1>
			<ol class="breadcrumb">
				<li><a href="#"><i class="fa fa-dashboard"></i> Inicio</a></li>
				<li class="active">Planificador</li>
			</ol>
		</section>
		
			<section class="content">
				<div class="row">
					<div class="col-md-12">
						<div class="box box-primary">
							<div class="box-header with-border">
								<small class="pull-right"><?php echo $hoy=date("F j, Y, g:i a") ?></small>
							</div>
							<div class="box-body">
								<div class="col-md-2">
									<div class="box box-solid">
									</div>
								</div>
								
								<div class="col-md-8">
									<div class="form-group">
										<div class="row">
											<div class="col-md-6">	
										<label>Nombre</label>
										<input type="text" id="nom"class="form-control" placeholder="Nombre" value="" required>
											</div>
										<div class="col-md-6">
										</div>
										<br/>	
										</div>
										<div class="row">
											<div class="col-md-3">	
												<div class="bootstrap-timepicker">
													<label>Hora inicio</label>	
													<div class="input-group">
														<input type="text" id="timeStat"class="form-control timepicker">
														<div class="input-group-addon">
															<i class="fa fa-clock-o"></i>
														</div>
													</div>
												</div>
											</div>	
											<div class="col-md-3">
												<div class="bootstrap-timepicker">
													<label>Hora fin</label>
													<div class="input-group">
														<input type="text" id="timeEnd"class="form-control timepicker">
														<div class="input-group-addon">
															<i class="fa fa-clock-o"></i>
														</div>
													</div>
												</div>
											</div>
										</div>
										<br/><p>Selecciona los días de la semana</p>	
										<div class="form-group">
											<label>
												<input type="checkbox" id="dia0" value="" class="minimal">
												Domingo
											</label>&nbsp&nbsp&nbsp&nbsp
											<label>
												<input type="checkbox" id="dia1" value="" class="minimal">
												Lunes
											</label>&nbsp&nbsp&nbsp&nbsp
											<label>
												<input type="checkbox" id="dia2" value="" class="minimal">
												Martes
											</label>&nbsp&nbsp&nbsp&nbsp
											<label>
												<input type="checkbox" id="dia3" value="" class="minimal">
												Miercoles
											</label>&nbsp&nbsp&nbsp&nbsp
											<label>
												<input type="checkbox" id="dia4" value="" class="minimal">
												Jueves
											</label>&nbsp&nbsp&nbsp&nbsp
											<label>
												<input type="checkbox" id="dia5" value="" class="minimal">
												Viernes
											</label>&nbsp&nbsp&nbsp&nbsp
											<label>
												<input type="checkbox" id="dia6" value="" class="minimal">
												Sabado
											</label>
										</div>
										<button onClick="addScheduler()" class="btn btn-primary pull-rigth">Agregar</button>
									</div>
								</div>									
								<div class="col-md-2">
									<div class="box box-solid">
									</div>
								</div>
								<div class="row">
									<div class="col-md-12">
										<div class="table-responsive">
											<table id="example1" class="table table-condensed ">
												<thead>
													<tr>
														<th>Nombre</th>
														<th>Dias</th>
														<th>Horas</th>
														<th>Estado</th>
														<th>Acción</th>
													</tr>
												</thead>
												<tbody>
													<?php while($sch_row=mysqli_fetch_array($sch_res)){ ?>
													<tr>
														<td><?php echo $sch_row[1]; ?></td>
														<td><?php echo $sch_row[4]." ".$sch_row[5]." ".$sch_row[6]." ".$sch_row[7]." ".$sch_row[8]." ".$sch_row[9]." ".$sch_row[10]; ?></td>
														<td><?php echo $sch_row[2]; ?> - <?php echo $sch_row[3]; ?></td>
														<td>
															<?php if($sch_row[11] == "1"){?>
															<i class="glyphicon glyphicon-ok-circle green-glyphicon">
															<?php } else { ?>
															<i class="glyphicon glyphicon-ban-circle red-glyphicon">
															<?php } ?>
														</td>
														<td>
															<?php if($sch_row[11] == "1"){?>
															<a href="#" onClick="stopScheduler('<?php echo $sch_row[0]; ?>')"><span class="glyphicon glyphicon-stop"></span></a>&nbsp&nbsp
															<?php } else { ?>
															<a href="#" onClick="playScheduler('<?php echo $sch_row[0]; ?>')"><span class="glyphicon glyphicon-play"></span></a>&nbsp&nbsp
															<?php } ?>
															<a href="#" onClick="delScheduler('<?php echo $sch_row[0]; ?>')"><span class="glyphicon glyphicon-remove"></span>															</a>
														</td>
												 	</tr>
												 	<?php } mysqli_close($db); ?> 										
												</tbody>
												<tfoot>
													<tr>
														<th>Nombre</th>
														<th>Dias</th>
														<th>Horas</th>
														<th>Estado</th>
														<th>Acción</th>
													</tr>
												</tfoot>
											</table>
										</div>
									</div>	
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			
			<script>
			$(function () {
		    //Timepicker
		    $('.timepicker').timepicker({
			  timeFormat: 'h:mm p',  
		      showInputs: false,
		    	})
		  	})
		  	//iCheck for checkbox and radio inputs
		    $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
		      checkboxClass: 'icheckbox_minimal-blue',
		      radioClass   : 'iradio_minimal-blue'
		    })
		    $(document).ready(function() {
				$('table.table-condensed').DataTable({
					"lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
					"order": [[ 3, 'asc' ]],
					"language": {
						"url": "../json/Spanish.json"
						}
					});
				});
				
		    function addScheduler() {
			    
			    if(document.getElementById("dia0").checked) {
				    document.getElementById('dia0').value = "DO";
			    }
			    if(document.getElementById("dia1").checked) {
				    document.getElementById('dia1').value = "LU";
			    }
			    if(document.getElementById("dia2").checked) {
				    document.getElementById('dia2').value = "MA";
			    }
			    if(document.getElementById("dia3").checked) {
				    document.getElementById('dia3').value = "MI";
			    }
			    if(document.getElementById("dia4").checked) {
				    document.getElementById('dia4').value = "JU";
			    }
			    if(document.getElementById("dia5").checked) {
				    document.getElementById('dia5').value = "VI";
			    }
			    if(document.getElementById("dia6").checked) {
				    document.getElementById('dia6').value = "SA";
			    }
			    
				//variables
				var nom = $("#nom").val();
				var timeStat = $("#timeStat").val();
				var timeEnd = $("#timeEnd").val();
				var dia0 = $("#dia0").val();
				var dia1 = $("#dia1").val();
				var dia2 = $("#dia2").val();
				var dia3 = $("#dia3").val();
				var dia4 = $("#dia4").val();
				var dia5 = $("#dia5").val();
				var dia6 = $("#dia6").val();
				
				//agregar
				$.post("../php/addScheduler.php", {
					nom: nom,
					timeStat: timeStat,
					timeEnd: timeEnd,
					dia0: dia0,
					dia1: dia1,
					dia2: dia2,
					dia3: dia3,
					dia4: dia4,
					dia5: dia5,
					dia6: dia6
				}, function(data, status){
					
					location. reload(); 
					
					$("#nom").val("");
					$("#timeStart").val("");
					$("#timeEnd").val("");
					$("#dia0").val("");
					$("#dia1").val("");
					$("#dia2").val("");
					$("#dia3").val("");
					$("#dia4").val("");
					$("#dia5").val("");
					$("#dia6").val("");
					
				});								
			}			
			//eliminar Tarea
			function delScheduler(id){
				
				$.post("../php/delScheduler.php", {
					id: id
					},
					function (data, status) {
						location. reload();
					}
				);
			}
			//detener Tarea
			function stopScheduler(id){
				
				$.post("../php/stpScheduler.php", {
					id: id
					},
					function (data, status) {
						location. reload();
					}
				);
			}
			
			//iniciar Tarea
			function playScheduler(id){
				
				$.post("../php/plyScheduler.php", {
					id: id
					},
					function (data, status) {
						location. reload();
					}
				);
			}
		    
			</script>
			
<?php } else { ?>
<section class="content">
	<div class="callout callout-warning">
		<h4>ALERTA!</h4><h4>Acceso no autorizado</h4>
		<p>Usted no tiene permisos para abrir esta pagina.</p>
	</div>
	<div class="row">
		<div class="col-xs-12">
		</div>
	</div>
</section>
<?php } ?>

<?php include "pie.php"; ?>
<?php } else { echo '<meta http-equiv="refresh" content="0; url=../bloqueado.php">'; } } else { echo '<meta http-equiv="refresh" content="0; url=../inactivo.php">'; } } else { echo '<meta http-equiv="refresh" content="0; url=../index.php">'; }?>