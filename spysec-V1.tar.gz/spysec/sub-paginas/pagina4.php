<?php $pagina = pathinfo($_SERVER['PHP_SELF'], PATHINFO_FILENAME); include '../inc/inc_db.php'; include '../php/variables.php';if($dbstanew == 1){ if($dbact == 1){ if($dblck == 0){ include "cbz.php"; if($dbper == 1 || $dbper == 2 || $dbper == 3){ ?>

		<section class="content-header">
			<h1>
				Red
				<small>Version 2.0</small>
			</h1>
			<ol class="breadcrumb">
				<li><a href="#"><i class="fa fa-dashboard"></i> Inicio</a></li>
				<li>Administración</li>
				<li class="active">Red</li>
			</ol>
		</section>
		
			<section class="content">
				<div class="row">
					<div class="col-md-12">
						<div class="box box-primary">
							<div class="box-header with-border">
								<small class="pull-right"><?php echo $hoy=date("F j, Y, g:i a") ?></small>
							</div>
							<div class="box-body">

								<div class="row">
									<div class="col-md-3">
									</div>
									<div class="col-md-6">
										<div class="row">
											<div class="col-md-3">										
												<dt>DHCP</dt>
											</div>
											<div class="col-md-9">	
												<div class="btn-group btn-group-toggle" data-toggle="buttons">
													<label class="btn btn-secondary btn-primary active">
														<input type="radio" name="options" id="option1" value="1" autocomplete="off" onchange="habilitar(this.value);" checked> Habilitar
													</label>
													<label class="btn btn-secondary btn-primary">
														<input type="radio" name="options" id="option2" value="2" autocomplete="off" onchange="habilitar(this.value);" > Deshabilitar
													</label>
  												</div>
											</div>
										</div>
										
										<br/>
										<div class="row">
											<div class="col-md-3">										
												<label>Dirección IP</label>
											</div>
											<div class="col-md-9">		
												<input id="ip" type="text" class="form-control">
											</div>	
										</div>
										<br/>
										<div class="row">
											<div class="col-md-3">										
												<label>Máscara de subred</label>
											</div>
											<div class="col-md-9">		
												<input id="mask" type="text" class="form-control">
											</div>	
										</div>
										<br/>
										<div class="row">
											<div class="col-md-3">										
												<label>Puerta de enlace IP</label>
											</div>
											<div class="col-md-9">		
												<input id="gw" type="text" class="form-control">
											</div>	
										</div>
										<br/>
										<div class="row">
											<div class="col-md-3">										
												<label>Servidor DNS</label>
											</div>
											<div class="col-md-9">		
												<input id="dns1" type="text" class="form-control">
											</div>	
										</div>
										<br/>
										<div class="row">
											<div class="col-md-3">
												<label>Servidor alternativo DNS</label>
											</div>
											<div class="col-md-9">		
												<input id="dns2" type="text" class="form-control">
											</div>	
										</div>
										<br/>
										<div class="row">
											<div class="col-md-10">
											</div>
											<div class="col-md-2">
												<button onClick="" class="btn btn-primary">Guardar</button>
											</div>	
										</div>
									</div>
									
									<div class="col-md-3">
									</div>
								</div>		
								
							</div>
						</div>
					</div>
				</div>
			</section>
			<script>
			
			function habilitar(value)
			{
				if(value=="1")
			{
				// habilitamos
				document.getElementById("ip").disabled=false;
				document.getElementById("mask").disabled=false;
				document.getElementById("gw").disabled=false;
				document.getElementById("dns1").disabled=false;
				document.getElementById("dns2").disabled=false;
			}else if(value=="2"){
				// deshabilitamos
				document.getElementById("ip").disabled=true;
				document.getElementById("mask").disabled=true;
				document.getElementById("gw").disabled=true;
				document.getElementById("dns1").disabled=true;
				document.getElementById("dns2").disabled=true;
			}
			}
			</script>

<?php } else { ?>
<section class="content">
	<div class="callout callout-warning">
		<h4>ALERTA!</h4><h4>Acceso no autorizado</h4>
		<p>Usted no tiene permisos para abrir esta pagina.</p>
	</div>
	<div class="row">
		<div class="col-xs-12">
		</div>
	</div>
</section>
<?php } ?>

<?php include "pie.php"; ?>
<?php } else { echo '<meta http-equiv="refresh" content="0; url=../bloqueado.php">'; } } else { echo '<meta http-equiv="refresh" content="0; url=../inactivo.php">'; } } else { echo '<meta http-equiv="refresh" content="0; url=../index.php">'; }?>
