<?php $pagina = pathinfo($_SERVER['PHP_SELF'], PATHINFO_FILENAME); include '../inc/inc_db.php'; include '../php/variables.php';if($dbstanew == 1){ if($dbact == 1){ if($dblck == 0){ include "cbz.php"; if($dbper == 1 ){ ?>

		<section class="content-header">
			<h1>
				Almacenamiento
				<small>Version 2.0</small>
			</h1>
			<ol class="breadcrumb">
				<li><a href="#"><i class="fa fa-dashboard"></i> Inicio</a></li>
				<li>Administración</li>
				<li class="active">Almacenamiento</li>
			</ol>
		</section>
		
			<section class="content">
				<div class="row">
					<div class="col-md-12">
						<div class="box box-primary">
							<div class="box-header with-border">
								<small class="pull-right"><?php echo $hoy=date("F j, Y, g:i a") ?></small>
							</div>
							<div class="box-body">
							</div>
						</div>
					</div>
				</div>
			</section>

<?php } else { ?>
<section class="content">
	<div class="callout callout-warning">
		<h4>ALERTA!</h4><h4>Acceso no autorizado</h4>
		<p>Usted no tiene permisos para abrir esta pagina.</p>
	</div>
	<div class="row">
		<div class="col-xs-12">
		</div>
	</div>
</section>
<?php } ?>

<?php include "pie.php"; ?>
<?php } else { echo '<meta http-equiv="refresh" content="0; url=../bloqueado.php">'; } } else { echo '<meta http-equiv="refresh" content="0; url=../inactivo.php">'; } } else { echo '<meta http-equiv="refresh" content="0; url=../index.php">'; }?>
