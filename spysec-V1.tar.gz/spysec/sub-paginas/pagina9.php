<?php $pagina = pathinfo($_SERVER['PHP_SELF'], PATHINFO_FILENAME); include '../inc/inc_db.php'; include '../php/variables.php';if($dbstanew == 1){ if($dbact == 1){ if($dblck == 0){ include "cbz.php"; if($dbper == 1 || $dbper == 2){
	if($dbper == 1){ $usr_sql="SELECT * FROM usuarios";		
	} elseif($dbper == 2) { $usr_sql='SELECT * FROM usuarios WHERE grupo="'.$dbgpo.'"'; }
	
	$usr_res=mysqli_query($db, $usr_sql);	
?>

		<section class="content-header">
			<h1>
				Usuarios
				<small>Version 2.0</small>
			</h1>
			<ol class="breadcrumb">
				<li><a href="#"><i class="fa fa-dashboard"></i> Inicio</a></li>
				<li>Administración</li>
				<li class="active">Usuarios</li>
			</ol>
		</section>
		
			<section class="content">
				<div class="row">
					<div class="col-md-12">
						<div class="box box-primary">
							<div class="box-header with-border">
								<small class="pull-right"><?php echo $hoy=date("F j, Y, g:i a") ?></small>
							</div>
							<div class="box-body">
								
								<div class="table-responsive">
									<table id="example1" class="table table-condensed ">
										<thead>
											<tr>
												<th>Nombre</th>
												<th>Usuario</th>
												<th>E-mail</th>
												<th>Activo</th>
												<th>Acciones</th>
											</tr>
										</thead>
										<tbody>
											<?php
											while($usr_row=mysqli_fetch_array($usr_res)){ 
												if($usr_row['perfil']  == "1"){ $str_perf=" Admin"; } elseif($usr_row['perfil'] == "2"){ $str_perf=" Editor"; } elseif($usr_row['perfil'] == "3"){ $str_perf=" Usuario"; }
												if($usr_row['bloqueado'] == "0" && $usr_row['activo'] == "0"){ $trcolor="active"; } elseif($usr_row['bloqueado'] == "0") { $trcolor=""; } elseif($usr_row['bloqueado'] == "1"){ $trcolor="danger"; }
												
												if($usr_row['bloqueado'] == "0"){ $btn_perf='btn-default'; $icn_blo="fa fa fa-lock"; $str_blo="Bloquear"; $fun_lock="lockData";
												} else { $btn_perf='btn-danger'; $icn_blo="fa fa fa-unlock"; $str_blo="Desbloquear"; $fun_lock="unlockData"; }
											?> 
											<tr class="<?php echo $trcolor ?>">
												<td><?php echo $usr_row[3]." ".$usr_row[4]; ?></td>
												<td><?php echo $usr_row[1]; ?></td>
												<td><?php echo $usr_row[6]; ?></td>
												<td>
													<?php if($usr_row['bloqueado'] == "1" && $usr_row['activo'] == "1" ){ ?><i class="fa fa-ban red-glyphicon">
													<?php } elseif($usr_row['activo'] == "0") { ?><i class="glyphicon glyphicon-remove-circle">
													<?php } elseif($usr_row['activo'] == "1") { ?><i class="glyphicon glyphicon-ok-circle green-glyphicon"><?php } ?>
												</td>
												<td>
													<div class="btn-group">
														<button type="button" onClick="rolUser('<?php echo $usr_row['id']; ?>')" class="btn <?php echo $btn_perf ?>">
															<i class="fa fa fa-user-secret"></i> <?php echo $str_perf; ?>
														</button>
														<button type="button" class="btn <?php echo $btn_perf ?> dropdown-toggle " data-toggle="dropdown">
															<span class="caret"></span>
															<span class="sr-only">Toggle Dropdown</span>
														</button>
														<ul class="dropdown-menu" role="menu">
															<li>
																<a href="#" onClick="getUser('<?php echo $usr_row['id']; ?>')">
																	<i class="glyphicon glyphicon-edit	"></i>Editar
																	
																</a>
															</li>
															<li> 
																<a href="#" onClick="pasUser('<?php echo $usr_row['id']; ?>')">
																	<i class="fa fa fa-key"></i>Contraseña
																</a>
															</li>													
															<li> 
																<a href="#" onClick="delUser('<?php echo $usr_row['id']; ?>')">
																	<i class="glyphicon glyphicon-trash"></i>Borrar
																</a>
															</li>
															<li>
																<?php if($usr_row['activo'] == "1"){ ?>
																<a href="#" onClick="<?php echo $fun_lock ?>('<?php echo $usr_row['id']; ?>')">
																	<i class="<?php echo $icn_blo; ?>"></i><?php echo $str_blo; ?>
																</a>
																<?php } else {?>
																<a href="#" onClick="actUser('<?php echo $usr_row['id']; ?>')">
																	<i class="glyphicon glyphicon-ok"></i>Activar
																</a>
																<?php }?>
															</li> 
														</ul>
													</div>
												</td>
											</tr>
											<?php } mysqli_close($db); ?>
										</tbody>
										<tfoot>
											<tr>
												<th>Nombre</th>
												<th>Usuario</th>
												<th>E-mail</th>
												<th>Activo</th>
												<th>Acciones</th>
											</tr>
										</tfoot>
									</table>
									<p>
										<button type="button" class="btn btn-info" data-toggle="modal" data-target="#usradd">
											<i class="glyphicon glyphicon-plus"></i> Agregar Usuario
										</button>
									</p>
								</div>	
							</div>
						</div>
					</div>
				</div>
			</section>
			
			<!-- Inicio Modal Agregar Usuario -->
			<div class="modal fade" id="usradd">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
							<h4 class="modal-title">Agregar Usuario</h4>
						</div>
						<div class="modal-body">
							<div class="form-group">
								<div class="margin">
									<label for="Usuario">Usuario</label>
									<input type="text" id="usr" value="" class="form-control" required/>
								</div>
							</div>
							<div class="form-group">
								<label for="Contraseña">Contraseña</label>
								<div class="input-group margin">
									<input type="password" id="pas" value="" class="form-control"/>
									<span class="input-group-btn">
										<button onClick="myFunction()" class="btn btn-default btn-flat"><i id="icon_pass" class="glyphicon glyphicon-eye-open"></i></button>
									</span>
								</div>
							</div>
							<div class="form-group">
								<div class="margin">
									<label for="Nombre">Nombre</label>
									<input type="text" id="nom" value="" class="form-control" required/>
								</div>
							</div>
							<div class="form-group">
								<div class="margin">
									<label for="Apellido">Apellido</label>
									<input type="text" id="ape" value="" class="form-control"/>
								</div>
							</div>
							<div class="form-group">
								<div class="margin">
									<label for="Puesto">Puesto</label>
									<input type="text" id="pue" value="" class="form-control"/>
								</div>
							</div>
							<div class="form-group">
								<div class="margin">
									<label for="E-mail">E-mail</label>
									<input type="text" id="eml" value="" class="form-control"/>
								</div>
							</div>
							<div class="form-group">
								<div class="margin">
									<label for="Rol">Nivel</label>
									<select class="form-control" id="rol">
										<option value="1">Admin</option>
										<option value="2">Editor</option>
										<option value="3" selected>Usuario</option>
									</select>
								</div>
							</div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default pull-rigth" data-dismiss="modal">Cerrar</button>
							<button onClick="addUser()" class="btn btn-primary pull-rigth">Agregar</button>
						</div>
					</div>
				</div>
			</div>
			<!-- Fin Agregar Usuario -->
			
			<!-- Inicio Modal Rol -->
			<div class="modal fade" id="rolUser">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
							<h4 class="modal-title">Editar Nivel de Usuario:</h4>
						</div>
						<div class="modal-body">
							<div class="form-group">
								<label for="Rol">Nivel</label>
								<select class="form-control" id="upd_rol">
									<option value="1">Admin</option>
									<option value="2">Editor</option>
									<option value="3">Usuario</option>
								</select>
								<label for="id" class="hidden">ID</label>
								<input type="id" id="hid_id" value="" class="form-control hidden"/>
							</div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default pull-rigth" data-dismiss="modal">Cerrar</button>
							<button onClick="updrolUser()" class="btn btn-primary pull-rigth">Actualizar</button>
						</div>
					</div>
				</div>
			</div>
			<!-- Fin Modal Rol -->
			
			<div class="modal fade" id="pasUser">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
							<h4 class="modal-title">Editar Nivel de Usuario:</h4>
						</div>
						<div class="modal-body">
							<div class="form-group">
								<label for="Rol">Cambiar contraseña</label>
								<div class="input-group margin">
									<input type="password" id="update_pass" value="" class="form-control"/>
									<span class="input-group-btn">
										<button onClick="myFunction()" class="btn btn-default btn-flat"><i id="icon_pass" class="glyphicon glyphicon-eye-open"></i></button>
									</span>
								</div>
								<label for="id" class="hidden">ID</label>
								<input type="id" id="hidpass_id" value="" class="form-control hidden"/>
							</div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default pull-rigth" data-dismiss="modal">Cerrar</button>
							<button onClick="passUser()" class="btn btn-primary pull-rigth">Actualizar</button>
						</div>
					</div>
				</div>
			</div>
			
			<!-- Inicio Modal Editar -->
			<div class="modal fade" id="updateUser">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
							<h4 class="modal-title">Editar Usuario</h4>
						</div>
						<div class="modal-body">
							<div class="form-group">
								<label for="usr">Usuario</label>
								<input type="text" id="update_usr" value="" class="form-control" disabled/>
							</div>
							<div class="form-group">
								<label for="nom">Nombre</label>
								<input type="text" id="update_nom" value="" class="form-control"/>
							</div>
							<div class="form-group">
								<label for="ape">Apellido</label>
								<input type="text" id="update_ape" value="" class="form-control"/>
							</div>
							<div class="form-group">
								<label for="pue">Puesto</label>
								<input type="text" id="update_pue" value="" class="form-control"/>
							</div>
							<div class="form-group">
								<label for="eml">E-mail</label>
								<input type="text" id="update_eml" value="" class="form-control"/>
								<label for="id" class="hidden">ID</label>
								<input type="id" id="Hupdate_id" value="" class="form-control hidden"/>
							</div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default pull-rigth" data-dismiss="modal">Cerrar</button>
							<button onClick="updateUser()" class="btn btn-primary pull-rigth">Actualizar</button>
							
						</div>
					</div>
				</div>
			</div>
			<!-- Fin Modal Editar -->
			
			
		<script>
			
			$(document).ready(function() {
				$('table.table-condensed').DataTable({
					"lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
					"order": [[ 3, 'asc' ]],
					"language": {
						"url": "../json/Spanish.json"
						}
					});
				});
			//agregar Usuario	
			function addUser(){
				var usr = $("#usr").val();
				var pas = $("#pas").val();
				var nom = $("#nom").val();
				var ape = $("#ape").val();
				var pue = $("#pue").val();
				var eml = $("#eml").val();
				var rol = $("#rol").val();
				
				$.post("../php/addUser.php",{
					usr: usr,
					pas: pas,
					nom: nom,
					ape: ape,
					pue: pue,
					eml: eml,
					rol: rol
				}, function(data, status){
						$("#usradd").modal("hide");
						location. reload();
					
						$("#usr").val("");
						$("#pas").val("");
						$("#nom").val("");
						$("#ape").val("");
						$("#pue").val("");
						$("#eml").val("");
						$("#rol").val("");
					}
				);		
			}
			//eliminar Usuario
			function delUser(id) {
				$.post("../php/delUser.php", {
						id: id
					},
				function (data, status) {
						location. reload();
					}
				);
			}
			//activar Usuario
			function actUser(id) {
				$.post("../php/actUser.php", {
						id: id
					},
				function (data, status) {
						location. reload();
					}
				);
			}
			//bloquear Usuario
			function lockData(id) {
				$.post("../php/lockUser.php", {
						id: id
					},
				function (data, status) {
						location. reload();
					}
				);
			}
			//desbloquear Usuario
			function unlockData(id) {
				$.post("../php/unlockUser.php", {
						id: id
					},
				function (data, status) {
						location. reload();
					}
				);
			}
			//editar rol-Usuario
			function rolUser(id) {
				$("#hid_id").val(id);
				$.post("../php/getUser.php", {
						id: id	
					},
				function(data, status) {
						var user = JSON.parse(data);				
						$("#upd_rol").val(user.perfil);
					}
				);
				$("#rolUser").modal("show");
			}
			//actualizar rol-Usuario
			function updrolUser() {
				var rol = $("#upd_rol").val();
				var id = $("#hid_id").val();
				
				$.post("../php/updrolUser.php", {
					id: id,					
					rol: rol
				},
				function (data, status) {
						$("#rolUser").modal("hide");
						location. reload();
					}
				);
			}
			//editar contraseñaUsuario
			function pasUser(id) {
				$("#hidpass_id").val(id);
				$("#pasUser").modal("show");
			}
			//actulizar contraseñaUsuario
			function passUser() {
				var pass = $("#update_pass").val();
				var id = $("#hidpass_id").val();
				$.post("../php/passUser.php", {
					id: id,
					pass: pass
				},
				function (data, status) {
						$("#pasUser").modal("hide");
						location. reload();
					}
				);
			}
			//editar Usuario
			function getUser(id) {
				$("#Hupdate_id").val(id);
				$.post("../php/getUser.php", {
						id: id
					},
				function(data, status) {
						var user = JSON.parse(data);
						$("#update_usr").val(user.usuario);
						$("#update_nom").val(user.nombre);
						$("#update_ape").val(user.apellido);
						$("#update_pue").val(user.puesto);
						$("#update_eml").val(user.email);
					}
				);
				$("#updateUser").modal("show");
			}
			//actualizar Usuario
			function updateUser() {
				var usr = $("#update_usr").val();
				var nom = $("#update_nom").val();
				var ape = $("#update_ape").val();
				var pue = $("#update_pue").val();
				var eml = $("#update_eml").val();
				var id = $("#Hupdate_id").val();
				
				$.post("../php/updateUser.php", {
					id: id,					
					usr: usr,					
					nom: nom,
					ape: ape,
					pue: pue,
					eml: eml
				},
				function (data, status) {
						$("#updateUser").modal("hide");
						location. reload();
					}
				);
			}
			function myFunction() {
				var x = document.getElementById("update_pass");
				var i = document.getElementById("pas");
				if (x.type === "password") {
					x.type = "text";
					} else {
						x.type = "password";
						}
				if (i.type === "password") {
					i.type = "text";
					} else {
						i.type = "password";
						}		
					}
			
		</script>
		
<?php } else { ?>
<section class="content">
	<div class="callout callout-warning">
		<h4>ALERTA!</h4><h4>Acceso no autorizado</h4>
		<p>Usted no tiene permisos para abrir esta pagina.</p>
	</div>
	<div class="row">
		<div class="col-xs-12">
		</div>
	</div>
</section>
<?php } ?>

<?php include "pie.php"; ?>
<?php } else { echo '<meta http-equiv="refresh" content="0; url=../bloqueado.php">'; } } else { echo '<meta http-equiv="refresh" content="0; url=../inactivo.php">'; } } else { echo '<meta http-equiv="refresh" content="0; url=../index.php">'; }?>