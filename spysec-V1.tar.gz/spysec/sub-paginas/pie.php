</div>
<footer class="main-footer">
		    	<div class="pull-right hidden-xs">
			    	<b>Version</b> 2.0
		    	</div>
				<strong>Copyright &copy; <?php echo $d=date("Y") ?></strong>
			</footer>
		</div>
	</body>
	
</html>